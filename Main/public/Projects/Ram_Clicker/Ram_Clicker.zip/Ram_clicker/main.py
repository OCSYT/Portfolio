from flask import Flask, render_template

App = Flask(__name__)


@App.route("/")
def MainPage():
    return render_template('main/index.html')

def Main():
    if (__name__ == "__main__"):
        App.run(debug=True)

Main()