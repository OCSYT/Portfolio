const MaxCPSElement = document.getElementById("MaxCPS");
const LevelProgressElement = document.getElementById("LevelProgress");
const LevelProgressTextElement = document.getElementById("LevelProgressText");
const LevelElement = document.getElementById("Level");
const MaxScoreElement = document.getElementById("MaxScore");
const CookiesElement = document.getElementById("CookieAcceptance");
const ShopContainer = document.getElementById("ShopContainer");
const StatsContainer = document.getElementById("StatsContainer");
const Stats = document.getElementById("Stats");
const CPSElement = document.getElementById("CPS");
const ShopElement = document.getElementById("Shop");
const ScoreElement = document.getElementById("Score");
const RamElement = document.getElementById("Ram");
const ScoreScaleDefault = 30;
let ScoreScale = 25;
const ScoreAmount = 1;


function CopyObject(Obj) {
  let ObjCopy = Object.assign({}, Obj);
  return ObjCopy;
}

const CookiesDataStatic = {
  Level: 0,
  LevelScore: 0,
  Score: 0,
  MaxScore: 0,
  MaxCPS: 0,
  CookiesEnabled: false,
  AutoClicker: false,
  AutoClickerLevel2: false,
  AutoClickerLevel3: false,
  AutoClickerLevel4: false
};

let CookiesData = CopyObject(CookiesDataStatic);




function Main() {
  CheckForCookies();
  if (document.cookie != "" || document.cookie == null) {
    CookiesData = JSON.parse(document.cookie);
  }

  DisplayScore();
  DisplayShop();
}

let ShopEnabled = false;
let FirstShopToggle = false;
function ToggleShop(){
  ShopEnabled = !ShopEnabled;
  if(!FirstShopToggle){
    ShopContainer.classList.remove("hidden");
  }
  if(ShopEnabled){
    ShopContainer.classList.add("shop-fadein");
    ShopContainer.classList.remove("shop-fadeout");
  }
  else{
    ShopContainer.classList.add("shop-fadeout");
    ShopContainer.classList.remove("shop-fadein");
  }
}

let StatsEnabled = false;
let FirstStatsToggle = false;
function ToggleStats(){
  StatsEnabled = !StatsEnabled;
  if(!FirstStatsToggle){
    StatsContainer.classList.remove("hidden");
  }
  if(StatsEnabled){
    StatsContainer.classList.add("stats-fadein");
    StatsContainer.classList.remove("stats-fadeout");
  }
  else{
    StatsContainer.classList.add("stats-fadeout");
    StatsContainer.classList.remove("stats-fadein");
  }
}


function DisplayShop() {
  const children = ShopElement.children;

  for (let i = children.length - 1; i >= 0; i--) {
    ShopElement.removeChild(children[i]);
  }

  AddShopItem(!CookiesData.AutoClicker, "Ram Downloader", 1000, "2 Ram per 0.5 seconds");

  AddShopItem(!CookiesData.AutoClickerLevel2, "Ram Downloader (Level 2)", 2000, "5 Ram per 1 seconds");

  AddShopItem(!CookiesData.AutoClickerLevel3, "Ram Downloader (Level 3)", 4000, "5 Ram per 0.2 seconds");

  AddShopItem(!CookiesData.AutoClickerLevel4, "Ram Downloader (Level 4)", 12000,"5 Ram per 0.1 seconds");
}

function AddShopItem(Available, Name, Cost, Description) {

  let Tooltip = document.createElement("div");
  Tooltip.classList.add("tooltip");
  let Tooltiptext = document.createElement("div");
  Tooltiptext.classList.add("tooltiptext");
  Tooltiptext.innerHTML = Description;
  Tooltip.appendChild(Tooltiptext);

  if (Available) {
    let AutoClickerItem = document.createElement("button");
    AutoClickerItem.setAttribute("onclick", "Buy(" + `"` + Name + `"` + " ," + Number(Cost) + ")");
    AutoClickerItem.classList.add('text-wrap');
    AutoClickerItem.classList.add('text-left');
    AutoClickerItem.classList.add('text-sm/[100%]');
    AutoClickerItem.classList.add('mt-5');
    AutoClickerItem.classList.add('hover:text-black');
    AutoClickerItem.innerText = Name + " " + "(" + Cost + ")";
    Tooltip.appendChild(AutoClickerItem);
  }
  else{
    let AutoClickerItem = document.createElement("button");
    AutoClickerItem.classList.add('text-red-500');
    AutoClickerItem.classList.add('text-wrap');
    AutoClickerItem.classList.add('text-left');
    AutoClickerItem.classList.add('text-sm/[100%]');
    AutoClickerItem.classList.add('mt-5');  
    AutoClickerItem.innerText = Name + " " + "(" + Cost + ")";
    Tooltip.appendChild(AutoClickerItem);
  }
  ShopElement.appendChild(Tooltip);
}

function Buy(Name, Cost) {

  if (Cost <= CookiesData.Score) {
    if (Name == "Ram Downloader") {
      CookiesData.AutoClicker = true;
    }
    if(Name == "Ram Downloader (Level 2)"){
      CookiesData.AutoClickerLevel2 = true;
    }
    if(Name == "Ram Downloader (Level 3)"){
      CookiesData.AutoClickerLevel3 = true;
    }
    if(Name == "Ram Downloader (Level 4)"){
      CookiesData.AutoClickerLevel4 = true;
    }


    CookiesData.Score -= Cost;
    document.cookie = JSON.stringify(CookiesData);
    DisplayScore();
    DisplayShop();
  }
}

let Clicks = 0;
let LevelProgress = 0;
let LevelRamp = ((CookiesData.Level+1)*1.25)*10;
function RamClick(Automatic, Multiplier) {
  CookiesData.Score = 1 * Multiplier + CookiesData.Score;
  CookiesData.LevelScore = 1 * Multiplier + CookiesData.LevelScore;
  if(CookiesData.LevelScore/10 >= LevelRamp){
    CookiesData.LevelScore = 0;
    CookiesData.Level++;
  }
  
  if(!Automatic){
    ScoreScale = 50;
  }

  DisplayScore();
  document.cookie = JSON.stringify(CookiesData);
  Clicks = Clicks + 1 * Multiplier;
} 


function DisplayScore(){
  LevelRamp =  ((CookiesData.Level+1)*1.25)*10;
  LevelProgress = Math.round(((CookiesData.LevelScore/10) / LevelRamp)*100);
  ScoreElement.innerText = "Ram: " + CookiesData.Score;
  LevelElement.innerText = "Level: " + CookiesData.Level;
  LevelProgressTextElement.innerText = "Level Progress: " + (LevelProgress) + "%";
  LevelProgressElement.style.width = LevelProgress + "%";
}

function CheckForCookies() {
  console.log("Checking For Cookies");
  if (document.cookie != "" || document.cookie == null) {
    CookiesElement.remove();
    console.log(JSON.parse(document.cookie));
  }
}


function EnableCookies() {
  CookiesElement.remove();
  CookiesData.CookiesEnabled = true;
  document.cookie = JSON.stringify(CookiesData);
}


function ClearProgress() {
  CookiesData = CopyObject(CookiesDataStatic);
  CookiesData.CookiesEnabled = true;
  DisplayScore();
  DisplayShop();
  document.cookie = JSON.stringify(CookiesData);
  console.log("Clearing Data");
  console.log(CookiesData);
}

function Clamp(num, min, max) {
  return num <= min
    ? min
    : num >= max
      ? max
      : num
}
function Lerp( a, b, t ) {
  return a + t * ( b - a );
 }


function AutoClick(Available, Multiplier){
  if(Available){
    RamClick(true, Multiplier);
  }
}

setInterval(() => AutoClick(CookiesData.AutoClicker, 2), 500); //500ms
setInterval(() => AutoClick(CookiesData.AutoClickerLevel2, 5), 1000); //1000ms
setInterval(() => AutoClick(CookiesData.AutoClickerLevel3, 5), 200); //200ms
setInterval(() => AutoClick(CookiesData.AutoClickerLevel4, 5), 100); //100ms

setInterval(() => {
  CookiesData.MaxScore = Math.max(...[CookiesData.MaxScore, CookiesData.Score]);;
  CookiesData.MaxCPS = Math.max(...[CookiesData.MaxCPS, CPS]);
  MaxCPSElement.innerText = "Max Ram per second: " + Math.round(CookiesData.MaxCPS*10)/10;;
  MaxScoreElement.innerText = "Max Ram: " + (CookiesData.MaxScore); 
  document.cookie = JSON.stringify(CookiesData);
}, 500);

let LastUpdate = 0;
let Time = 0;
let OldCPS = 0;
let CPS = 0; //Clicks per second
function Update() {
  requestAnimationFrame(Update);
  let Now = performance.now();
  let DeltaTime = (Now - LastUpdate) / 1000;
  LastUpdate = Now;
  Time += DeltaTime;
  
  if(Time >= 1){
    OldCPS = CPS;
    CPS = (Clicks / Time);
    Time = 0;
    Clicks = 0;
  }


  OldCPS = Lerp(OldCPS, CPS, Clamp(15 * DeltaTime, 0, Infinity));

  
  CPSElement.innerText = "Ram per second: " + Math.round(OldCPS*10)/10;

  RamElement.style.width = ScoreScale + "%";

  ScoreScale += -ScoreAmount * 50 * DeltaTime;

  ScoreScale = Clamp(ScoreScale, ScoreScaleDefault, Infinity);
}

requestAnimationFrame(Update);
Main();